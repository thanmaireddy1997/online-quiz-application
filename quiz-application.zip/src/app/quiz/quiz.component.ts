import { Component, OnInit } from '@angular/core';
import { Subscriber } from 'rxjs';
import { Ques, Question } from '../question.service';

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {

  constructor( private questions: Question) { }

  count = 0;

  questionsObj: Ques[];

  msg2: string;

  ngOnInit(): void {

    this.questions.loadData().subscribe(result => this.questionsObj = result);
  }

  validate(): void{

    console.log(this.count);

    alert('Your score is: '+this.count);
    console.log('validate function');
  }

  clicked(id: number, sel: string, answer: string) : void {
    if(sel === answer){
      this.count++;
    }
    console.log(id + ' ' + sel + ' ' + answer);
  }
}
