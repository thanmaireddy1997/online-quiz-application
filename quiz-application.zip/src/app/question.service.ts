import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

// import sampleData from './questions.json';

@Injectable()
export class Question{
  constructor(private httpClient: HttpClient) { }

//  questions: any = sampleData;

  loadData(): Observable<Ques[]>{
    return this.httpClient.get<any>('./assets/questions.json');
  }

}

export class Ques {
  constructor(public id: number,
              public question: string,
              public options: boolean[],
              public answer: string,
              ){

  }
}
